// SC BY © VYNAA CHAN
// RECODE WAJIB KASI CREDITS 
// WA: 6282389924037
// TOKO KEBUTUHAN BOT TERPERCAYA
// HANYA DI SINI
// https://linkbio.co/VLShop
// https://t.me/VynaaMD
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
/*=========== LINK ============*/
global.link = {
	ig: 'https://instagram.com',
	gh: 'https://github.com',
	gc: 'https://chat.whatsapp.com/GSZqoHHFhVu7FHM0rjOrYS',
	web: 'https://tiktok.com/@won.preset',
	yt: 'https://tiktok.com/@won.preset',
	fb: 'https://tiktok.com/@won.preset',
    tree: 'https://tiktok.com/@won.preset',
	nh: 'https://nhentai.net/g/365296/'	
}
/*===========PAYMENT==========*/
/*============DONASI===========*/
global.pay = {
	dana: '62881036925623',
	ovo: '_',
	gopay: '6285921746819',
	pulsa: '6285921746819',
	qris: 'https://telegra.ph/file/bb4d87b1495008594143c.jpg'
}
/*==============================*/
/*========= NOMOR ============*/
global.info = {
	nomorbot: '62881036925623',
	nomorown: '6285921746819',
	namebot: '© 2024 Yuna AI',
	nameown: 'Tyan-®'
}
/*==============================*/
/*=========== STAFF ============*/
global.owner = [
    ['6285921746819', 'Tyan-®', 'true']
]
global.mods = [] 
global.prems = [] 
/*==============================*/
/*=========== GlobalAPI ============*/
global.zein = 'zenzkey_848b800b1f'
global.skizo = 'pinott'
global.rose = 'Rk-Ashbornt'
global.lol = 'GataDios'
global.neoxr = 'Sanzxdid'
global.can = 'ItsukaChan'
global.btc = 'tyan'
/*==============================*/
/*==============API ==============*/
global.APIs = {
    // API Prefix
    // name: 'https://website'
    xteam: 'https://api.xteam.xyz',
    lol: 'https://api.lolhuman.xyz',
    males: 'https://malesin.xyz',
    zein: 'https://api.zahwazein.xyz',
    rose: 'https://api.itsrose.life',
    skizo: 'https://skizo.tech',
    saipul: 'https://saipulanuar.cf'
}
global.APIKeys = {
    // APIKey Here
    // 'https://website': 'apikey'
    'https://api.zahwazein.xyz': 'zenzkey_848b800b1f',
    'https://api.xteam.xyz': 'cristian9407',
    'https://api.lolhuman.xyz': 'Abribotxd',
    'https://api.itsrose.life': 'Rk-Ashbornt',
    'https://skizo.tech' : 'pinott'
}
/*==============================*/
/*======== WATERMARK ========*/
global.versibot = '10.15'
global.wm = '© 2024 Yuna AI' 
global.author = 'Tyan-®'
global.wait = '_「P R O C E S S 」_'
/*==============================*/
global.fsizedoc = '99999999999999'
global.fpagedoc = '999'
/*======= TYPE DOCUMENT ======*/
global.doc = {
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    pdf: 'application/pdf',
    rtf: 'text/rtf'
}
/*==============================*/
/*========== HIASAN ===========*/
global.decor = {
	menut: '❏═┅═━–〈',
	menub: '┊•',
	menub2: '┊',
	menuf: '┗––––––––––✦',
	hiasan: '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷',

	menut: '––––––『',
    menuh: '』––––––',
    menub: '┊☃︎ ',
    menuf: '┗━═┅═━––––––๑\n',
	menua: '',
	menus: '☃︎',

	htki: '––––––『',
	htka: '』––––––',
	haki: '┅━━━═┅═❏',
	haka: '❏═┅═━━━┅',
	lopr: 'Ⓟ',
	lolm: 'Ⓛ',
	htjava: '❃'
}
/*=========== FOTO ============*/
global.elainajpg = [
    'https://telegra.ph/file/8441aaf691685ca350c76.png',
    'https://telegra.ph/file/079d14e4d07fc2d3dc582.mp4',
    'https://telegra.ph/file/3707c1b58d4bb00b6dcf3.png',]
global.vynaajpg = 'https://telegra.ph/file/0f30b8e2dc70610b027dd.jpg',    
// INI THUMBNAIL 
global.thumbnail = 'https://telegra.ph/file/0f30b8e2dc70610b027dd.jpg',    
/*==============================*/
/*==============================*/
// WELCOME GOOD BYE 
global.wel = 'https://telegra.ph/file/ddc2589307fe851dfa1db.mp4',
global.good = 'https://telegra.ph/file/b262558cf65343c584e64.mp4',
/*==============================*/
/*==============================*/
global.flaaa = [
    'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',
    'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text='
]
global.hwaifu = [
    'https://i.pinimg.com/originals/ed/34/f8/ed34f88af161e6278993e1598c29a621.jpg',
    'https://i.pinimg.com/originals/85/4d/bb/854dbbd30304cd69f305352f0183fad0.jpg',
]

/*==================================*/
/*======== STICKER WM ============*/
global.stickpack = 'TT @won.preset'
global.stickauth = '© Yuna AI'

global.multiplier = 69 // The higher, The harder levelup
/*===================================*/
/*============== EMOJI ==============*/
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            skata: '🧩'
        }
        let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
        if (!results.length) return ''
        else return emot[results[0][0]]
    }
}

//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'config.js'"))
    import(`${file}?update=${Date.now()}`)
})
